package co.edu.eam.sistemasdistribuidos.borrownotificator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorrowNotificatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BorrowNotificatorApplication.class, args);
	}

}
