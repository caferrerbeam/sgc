package co.edu.eam.sistemasdistribuidos.borrownotificator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowNotificatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
